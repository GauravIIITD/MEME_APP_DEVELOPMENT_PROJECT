# MemeApp
App simple app which shows random memes using API and also share these memes with friends
